# Импорт данных из файла
# Ввод данных с клавиатуры (ученик + класс)
# Редактирование данных (могу ли в общем словаре менять класс?)
# Удаление данных (ученика, всего класса)

import check as ch
import actions_files as af

myDict = {}

def from_file():
    pass

# Добавление ученика и класса. Если класса нет, добавляем и его с новым учеником.
def create_student():
    name_class = input('Введите класс: ')
    name_stud = input('Введите ФИО ученика: ')
    comm_stud = input('Введите данные: ')
    if name_class in myDict: # - можно ли сделать через setdefault()?
        myDict[name_class][name_stud] = comm_stud
    else:
        temp_dict={}
        temp_dict[name_stud] = comm_stud
        myDict[name_class] = temp_dict
    af.add_entry(myDict)
    ch.press_key()

def create_cl(name_class=False):
    pass

def edit_student():
    pass

def delete_student():
    pass

