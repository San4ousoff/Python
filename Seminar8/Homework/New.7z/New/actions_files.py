# Запись словаря в файл
# Получение данных из файла 

def add_entry(db):
    with open('Seminar8/Homework/New/dict_students.txt', 'w', encoding = 'utf-8') as file:
        for key, value in db.items():
            for k, v in value.items():
                file.write(f'{key}, {k}, {v}\n')

def receive_entry():
    temp_lst = []
    with open(r'Seminar8/Homework/New/dict_students.txt', 'r', encoding="utf-8") as file:
        for line_numb, line in enumerate(file, start=1):
            temp_lst.append(str(line_numb) + '. ' + line[:(-1)])
    return line_numb, temp_lst
    
