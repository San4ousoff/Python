# Вывод в консоль
# Вывод в файл

import import_data as id
import export_data as ed
import actions_files as af
import check as ch

def to_console():
    ch.clear()
    print('<<< Просмотр >>>')
    last_num, lst_data = af.receive_entry
    for view in lst_data:
        print(view)
    ch.press_key()


def to_file():
    pass