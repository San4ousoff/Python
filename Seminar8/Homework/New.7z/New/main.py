import user_interface as ui


def main():
    ui.user_choose()


if __name__ == '__main__':
    main()

# myDict = {
#     '1а':{'Иванов АА':'двоешник', 'Сидоров АБ':'троешник' }, 
#     '2а':{'Петров СС':'отличник', 'Иванов ИР':'троешник'}
# }
# print(myDict)
# name_class = input('Введите класс: ')
# name_stud = input('Введите ФИО ученика: ')
# comm_stud = input('Введите данные: ')
# if name_class in myDict:
#     myDict[name_class][name_stud] = comm_stud
# else:
#     temp_dict={}
#     temp_dict[name_stud] = comm_stud
#     myDict[name_class] = temp_dict
#     print(myDict)

# print(myDict)

# # err = 'Ошибка'
# # print(myDict.get(name_class))